Fil rouge Serverless
